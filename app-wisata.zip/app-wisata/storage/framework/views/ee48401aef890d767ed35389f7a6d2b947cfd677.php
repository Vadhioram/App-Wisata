<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('wisatas.update',$wisata->id)); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <label for="">Gambar</label>
    <input type="file" name="gambar" class="form-control" id="">
    <label for="">Nama</label>
    <input type="text" name="nama" id="" class="form-control" value="<?php echo e($wisata->nama); ?>">
    <label for="">Kota</label>
    <input type="text" name="kota" id="" class="form-control" value="<?php echo e($wisata->kota); ?>">
    <label for="">Harga</label>
    <input type="text" name="harga_tiket" id="" class="form-control" value="<?php echo e($wisata->harga_tiket); ?>"><br>
    <input type="submit" class="btn btn-secondary" value="Save">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Documents/app-wisata/resources/views/wisatas/edit.blade.php ENDPATH**/ ?>