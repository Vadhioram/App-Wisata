<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('wisatas.store')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <label for="">Gambar</label>
    <input type="file" name="gambar" class="form-control" id="">
    <label for="">Nama</label>
    <input type="text" name="nama" class="form-control" id="">
    <label for="">Kota</label>
    <input type="text" name="kota" class="form-control" id="">
    <label for="">Harga</label>
    <input type="text" name="harga_tiket" class="form-control" id=""><br>
    <input type="submit" class="btn btn-secondary" value="Save">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Documents/app-wisata/resources/views/wisatas/create.blade.php ENDPATH**/ ?>