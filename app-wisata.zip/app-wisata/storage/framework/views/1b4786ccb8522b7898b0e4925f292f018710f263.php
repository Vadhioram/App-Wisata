<?php $__env->startSection('content'); ?>
<h3><strong>Data</strong>
<a href="<?php echo e(route('wisatas.create')); ?>" class="btn btn-primary float-end">Add Data</a></h3>

<table class="table">
    <tr class="table-dark" align="center">
        <th>Gambar</th>
        <th>Nama</th>
        <th>Kota</th>
        <th>Harga</th>
        <th>Opsi</th>
    </tr>
    <?php $__currentLoopData = $wisatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr align="center">
            <td><img src="<?php echo e(Storage::url('public/image/'. $w->gambar)); ?>" alt="" style="width: 150px;"></td>
            <td><?php echo e($w->nama); ?></td>
            <td><?php echo e($w->kota); ?></td>
            <td><?php echo e($w->harga_tiket); ?></td>
            <td>
                <a href="<?php echo e(route('wisatas.show',$w->id)); ?>" class="btn btn-warning">Show</a>
                <a href="<?php echo e(route('wisatas.edit',$w->id)); ?>" class="btn btn-success">Edit</a>
                <form action="<?php echo e(route('wisatas.destroy',$w->id)); ?>" method="post" style="display:inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-danger">Delete</button>
            </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
    <?php echo e($wisatas->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Documents/app-wisata/resources/views/wisatas/index.blade.php ENDPATH**/ ?>