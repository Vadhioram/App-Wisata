<?php $__env->startSection('content'); ?>

<table class="table">
    <tr>
        <td><img src="<?php echo e(Storage::url('public/image/'. $wisata->gambar)); ?>" alt="" style="width: 150px;"></td>
        <td>Nama : <?php echo e($wisata->nama); ?></td>
        <td>Kota : <?php echo e($wisata->kota); ?></td>
        <td>Harga : <?php echo e($wisata->harga_tiket); ?></td>
    </tr>
    
</table>
<a href="<?php echo e(route('wisatas.index')); ?>" class="btn btn-dark">Back</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Documents/app-wisata/resources/views/wisatas/show.blade.php ENDPATH**/ ?>