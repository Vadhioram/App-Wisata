<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Wisata;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;

class WisataController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $wisatas = Wisata::paginate(2);
        return view('wisatas.index',['wisatas'=>$wisatas]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('wisatas.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
        'nama'=>'required',
        'kota'=>'required',
        'harga_tiket'=>'required',
        'gambar'=>'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048']);
        $gambar = $request->file('gambar');
        $gambar->storeAs('public/image/',$gambar->hashName());

        Wisata::create([
            'nama'=>$request->nama,
            'kota'=>$request->kota,
            'harga_tiket'=>$request->harga_tiket,
            'gambar'=>$gambar->hashName(),

        ]);
        return redirect()->route('wisatas.index')->with('success','Data Uploaded');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Wisata $wisata)
    {
        return view('wisatas.show',['wisata'=>$wisata]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Wisata $wisata)
    {
        return view('wisatas.edit',['wisata'=>$wisata]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,Wisata $wisata)
    {
        $request->validate([
            'nama'=>'required',
            'kota'=>'required',
            'harga_tiket'=>'required',
            'gambar'=>'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048']);
        if ($request->has('gambar')){
            $gambar = $request->file('gambar');
            $gambar->storeAs('public/image/',$gambar->hashName());

            Storage::delete('public/image/'. $wisata->image);
            $wisata->update([
                'nama'=>$request->nama,
                'kota'=>$request->kota,
                'harga_tiket'=>$request->harga_tiket,
                'gambar'=>$gambar->hashName(),
    
            ]);    
        }else{
            $wisata->update([
                'nama'=>$request->nama,
                'kota'=>$request->kota,
                'harga_tiket'=>$request->harga_tiket
            ]);
        }

        return redirect()->route('wisatas.index')->with('success','Data updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Wisata $wisata)
    {
        Storage::delete('public/image/'. $wisata->gambar);

        $wisata->delete();

        return redirect()->route('wisatas.index')->with('success','Data deleted');
    }
}
