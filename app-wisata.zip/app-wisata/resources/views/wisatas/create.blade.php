@extends('wisatas.template')
@section('content')
    <form action="{{ route('wisatas.store') }}" method="post" enctype="multipart/form-data">
    @csrf
    <label for="">Gambar</label>
    <input type="file" name="gambar" class="form-control" id="">
    <label for="">Nama</label>
    <input type="text" name="nama" class="form-control" id="">
    <label for="">Kota</label>
    <input type="text" name="kota" class="form-control" id="">
    <label for="">Harga</label>
    <input type="text" name="harga_tiket" class="form-control" id=""><br>
    <input type="submit" class="btn btn-secondary" value="Save">
    </form>
@endsection