@extends('wisatas.template')

@section('content')
<form action="{{ route('wisatas.update',$wisata->id) }}" method="post" enctype="multipart/form-data">
    @csrf
    @method('PUT')
    <label for="">Gambar</label>
    <input type="file" name="gambar" class="form-control" id="">
    <label for="">Nama</label>
    <input type="text" name="nama" id="" class="form-control" value="{{ $wisata->nama }}">
    <label for="">Kota</label>
    <input type="text" name="kota" id="" class="form-control" value="{{ $wisata->kota }}">
    <label for="">Harga</label>
    <input type="text" name="harga_tiket" id="" class="form-control" value="{{ $wisata->harga_tiket }}"><br>
    <input type="submit" class="btn btn-secondary" value="Save">
    </form>
@endsection