@extends('wisatas.template')

@section('content')
<h3><strong>Data</strong>
<a href="{{ route('wisatas.create') }}" class="btn btn-primary float-end">Add Data</a></h3>

<table class="table">
    <tr class="table-dark" align="center">
        <th>Gambar</th>
        <th>Nama</th>
        <th>Kota</th>
        <th>Harga</th>
        <th>Opsi</th>
    </tr>
    @foreach ($wisatas as $w)
        <tr align="center">
            <td><img src="{{ Storage::url('public/image/'. $w->gambar) }}" alt="" style="width: 150px;"></td>
            <td>{{ $w->nama }}</td>
            <td>{{ $w->kota }}</td>
            <td>{{ $w->harga_tiket }}</td>
            <td>
                <a href="{{ route('wisatas.show',$w->id) }}" class="btn btn-warning">Show</a>
                <a href="{{ route('wisatas.edit',$w->id) }}" class="btn btn-success">Edit</a>
                <form action="{{ route('wisatas.destroy',$w->id) }}" method="post" style="display:inline">
                @csrf
                @method('DELETE')
                <button class="btn btn-danger">Delete</button>
            </form>
            </td>
        </tr>
    @endforeach
</table>
    {{ $wisatas->links() }}
@endsection