@extends('wisatas.template')

@section('content')

<table class="table">
    <tr>
        <td><img src="{{ Storage::url('public/image/'. $wisata->gambar) }}" alt="" style="width: 150px;"></td>
        <td>Nama : {{ $wisata->nama }}</td>
        <td>Kota : {{ $wisata->kota }}</td>
        <td>Harga : {{ $wisata->harga_tiket }}</td>
    </tr>
    
</table>
<a href="{{ route('wisatas.index') }}" class="btn btn-dark">Back</a>
@endsection